				<h1 class="center-title"><?php echo 'Selamat Datang di '.CHtml::encode(Yii::app()->name); ?></h1>

				<p class="center">Mendidik dan menyalurkan Baby Sitter, PRT, Perawat OS/OJ, Supir, Tukang Kebun, Lokal dan Luar Kota</p>
