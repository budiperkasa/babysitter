<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/css/settings.css" media="screen" />
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/css/animation.css" />
<!--[if lt IE 9]> <script type="text/javascript" src="http://www.babysitterhidupmulia.com/js/customM.js"></script> <![endif]-->      
            <!-- Header Slider -->
            <div class="head-slider">
            	<div class="fullwidthbanner-container">
					<div class="fullwidthbanner">
						<ul>
							<!-- THE FIRST SLIDE -->  
							<li data-transition="3dcurtain-vertical" data-slotamount="10" data-masterspeed="300" data-thumb="<?php echo Yii::app()->baseUrl; ?>/images/thumbs/thumb1.jpg">
										<img src="<?php echo Yii::app()->baseUrl; ?>/images/slides/bg2.jpg" alt="MyPassion" />
										
                                        <div class="caption lfb ltb"
											 data-x="0"
											 data-y="70"
											 data-speed="600"
											 data-start="800"
											 data-easing="easeOutExpo" data-end="8100" data-endspeed="600" data-endeasing="easeInSine" ><img src="<?php echo Yii::app()->baseUrl; ?>/images/slides/alphard_white.png" alt="MyPassion"></div>                          
                                             
                                        <div class="caption mypassion-title lft ltt"
											 data-x="466"
											 data-y="100"
											 data-speed="600"
											 data-start="900"
											 data-easing="easeOutExpo" data-end="8200" data-endspeed="600" data-endeasing="easeInSine" ><span style="color:#03d3f8;">Pramuwisma.com</span><br/>  Penyalur Baby Sitter & PRT terbaik</div>

                                        <div class="caption mypassion-text lfr ltr"
											 data-x="466"
											 data-y="220"
											 data-speed="600"
											 data-start="1000"
											 data-easing="easeOutExpo"  data-end="8300" data-endspeed="600" data-endeasing="easeInSine" > 
											 <p>Pramuwisma.com adalah partner Anda dalam mencari, memilih dan menemukan Asisten Rumah Tangga <br> dan tenaga kerja lain yang tepat, sesuai dengan kebutuhan rumah tangga Anda.<br> Kami mendidik serta menyalurkan seperti: </p>
											 <table width="100%">
												<tr>
													<td>» Baby Sitter </td> 
												<td>» Tukang Kebun </td> 
												</tr>
												<tr>
													<td>» Pembantu Rumah Tangga</td>
													<td>» Perawat OS / OJ</td>	
														</tr>
												<tr>
																				
													<td>» Supir</td>
												</tr>
												
																							
											 </table>
											 </div> 
                                        
                          
                            </li>
                                     

							<!-- THE SECOND SLIDE -->
							<li data-transition="papercut" data-slotamount="15" data-masterspeed="300" data-delay="9400" data-thumb="<?php echo Yii::app()->baseUrl; ?>/images/thumbs/thumb2.jpg">
										<img src="<?php echo Yii::app()->baseUrl; ?>/images/slides/bg1.jpg" alt="MyPassion" />

										<div class="caption randomrotate"
											 data-x="0"
											 data-y="70"
											 data-speed="600"
											 data-start="800"
											 data-easing="easeOutExpo" data-end="8100" data-endspeed="600" data-endeasing="easeInSine" ><img src="<?php echo Yii::app()->baseUrl; ?>/images/slides/responsive2.png" alt="MyPassion"></div>                          
                                             
                                        <div class="caption mypassion-themecolor-fixedwidth lft ltt"
											 data-x="620"
											 data-y="100"
											 data-speed="600"
											 data-start="900"
											 data-easing="easeOutExpo" data-end="7200" data-endspeed="600" data-endeasing="easeInSine" >Pramuwisma.com</div>
                                             
                                        <div class="caption mypassion-themecolor-fixedwidth lft ltt"
											 data-x="620"
											 data-y="140"
											 data-speed="600"
											 data-start="1100"
											 data-easing="easeOutExpo" data-end="7500" data-endspeed="600" data-endeasing="easeInSine" >Kenapa Harus Kami ??</div>
                                             
                                        <div class="caption mypassion-greycolor-fixedwidth lfb ltt"
											 data-x="620"
											 data-y="200"
											 data-speed="600"
											 data-start="1400"
											 data-easing="easeOutExpo" data-end="8200" data-endspeed="600" data-endeasing="easeInSine" ><i class="icon-right-open"></i> Tenaga Profesional yang berpengalaman.</div>
                                        
                                        <div class="caption mypassion-greycolor-fixedwidth lfb ltt"
											 data-x="620"
											 data-y="245"
											 data-speed="600"
											 data-start="1600"
											 data-easing="easeOutExpo" data-end="8400" data-endspeed="600" data-endeasing="easeInSine" ><i class="icon-right-open"></i> Tenaga kerja Jujur, Baik, Ramah, dan Cekatan.  </div>
                                        
                                        <div class="caption mypassion-greycolor-fixedwidth lfb ltt"
											 data-x="620"
											 data-y="290"
											 data-speed="600"
											 data-start="1800"
											 data-easing="easeOutExpo" data-end="8600" data-endspeed="600" data-endeasing="easeInSine" ><i class="icon-right-open"></i> Berstandar panduan dari Dinas Tenaga Kerja.</div>
                                        
                                        <div class="caption mypassion-greycolor-fixedwidth lfb ltt"
											 data-x="620"
											 data-y="335"
											 data-speed="600"
											 data-start="2000"
											 data-easing="easeOutExpo" data-end="8800" data-endspeed="600" data-endeasing="easeInSine" ><i class="icon-right-open"></i>Tenaga kerja dibekali pendidikan dasar.</div>
                                        
                                        <div class="caption mypassion-greycolor-fixedwidth lfb ltt"
											 data-x="620"
											 data-y="380"
											 data-speed="600"
											 data-start="2200"
											 data-easing="easeOutExpo" data-end="9000" data-endspeed="600" data-endeasing="easeInSine" ><i class="icon-right-open"></i>Dan masih banyak lagi layanan kami.</div>
							</li>
                            
                            <!-- THE THIRD SLIDE -->
							<li data-transition="turnoff" data-slotamount="1" data-masterspeed="300" data-thumb="<?php echo Yii::app()->baseUrl; ?>/images/thumbs/thumb3.jpg">
										<img src="<?php echo Yii::app()->baseUrl; ?>/images/slides/bg3.jpg" alt="MyPassion" />

										<div class="caption lfb ltb"
											 data-x="80"
											 data-y="20"
											 data-speed="600"
											 data-start="800"
											 data-easing="easeOutExpo" data-end="7900" data-endspeed="600" data-endeasing="easeInSine" ><img src="<?php echo Yii::app()->baseUrl; ?>/images/slides/staff.png" alt="MyPassion" /></div>
                                        
                                       
                                        <div class="caption mypassion-title-caption-large lfr ltr"
											 data-x="850"
											 data-y="110"
											 data-speed="600"
											 data-start="1100"
											 data-easing="easeOutExpo" data-end="8400" data-endspeed="600" data-endeasing="easeInSine" >24 Hour</div>
                                             
                                        <div class="caption mypassion-title-caption-small lfr ltr"
											 data-x="1012"
											 data-y="70"
											 data-speed="600"
											 data-start="900"
											 data-easing="easeOutExpo" data-end="8200" data-endspeed="600" data-endeasing="easeInSine" >SERVICES</div>     
							</li>
						</ul>
						<div class="tp-bannertimer tp-bottom"></div>
					</div>
				</div>
            </div>
<!-- SCRIPTS -->
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/easing.min.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/ui.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/modernizr.custom.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/nicescroll.min.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/sticky.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/superfish.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/jflickrfeed.min.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/flexslider-min.js"></script>
<!-- jQuery REVOLUTION Slider -->
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/jquery.themepunch.plugins.min.js"></script>
<!--[if lt IE 9]> <script type="text/javascript" src="js/html5.js"></script> <![endif]-->
<script type="text/javascript" src="<?php echo Yii::app()->theme->baseUrl; ?>/js/mypassion.js"></script>
