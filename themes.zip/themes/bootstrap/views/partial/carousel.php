<?php $this->widget('bootstrap.widgets.TbCarousel', array(

	'items'=>array(

		array(

		'image'=>'images/first-placeholder830x400.gif',

		'label'=>'First Carousel',

		'caption'=>'Lorem',

		),

		array(

		'image'=>'images/second-placeholder830x400.gif',

		'label'=>'Second Carousel',

		'caption'=>'Ipsum',

		),

		array(

		'image'=>'images/third-placeholder830x400.gif',

		'label'=>'Third Carousel',

		'caption'=>'Dollor',

		),

	),

)); ?>
